LifePilot BD — installable offline-first web app prototype

WHAT'S INCLUDED
- Empty-by-default dashboard and user-created tasks/routines
- Habit tracker with daily check-ins
- Five daily prayer check-ins
- Study/tuition list and Pomodoro timer
- BDT income/expense tracker with Cash, bKash, Nagad, Bank, Card and Other
- Career milestones with progress sliders
- Local reflection coach (no AI service connection yet)
- Optional profile name/photo, light/dark theme
- JSON export/import and delete-all controls
- Bangladesh date/time display (Asia/Dhaka)
- Browser local storage and service-worker offline shell

RUN ON ANDROID
1. Host this folder on an HTTPS static host (for example, a static site host you control).
2. Open the site in Chrome on your Android phone.
3. Use Chrome menu > Add to Home screen / Install app.
4. Open LifePilot BD from the home screen.

IMPORTANT LIMITATIONS
- This is a working browser/PWA prototype, not a signed Android APK.
- Data is stored in this browser's local storage, not arbitrary phone folders. Export a backup before clearing browser data or switching devices.
- Firebase sync, account login, cloud backup, prayer-time calculation, push notifications, live AI coach, and ad SDK are not configured. They require service credentials, permission choices, or additional implementation.
- Pomodoro countdown works while the app page is open; background notifications/alarms are not implemented.
- Keep the app on a trusted HTTPS host for PWA installation and offline caching.
